import React, { useState, useCallback, useRef } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { ImageUploader } from './components/ImageUploader';
import { GeneratedImageDisplay } from './components/GeneratedImageDisplay';
import { generateHuggingImage, applyImageFilter } from './services/geminiService';

// Utility to convert File to Base64
const fileToBase64 = (file: File): Promise<{ data: string; mimeType: string }> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      const base64Data = result.split(',')[1];
      resolve({ data: base64Data, mimeType: file.type });
    };
    reader.onerror = (error) => reject(error);
  });
};

const App: React.FC = () => {
  const [childPhoto, setChildPhoto] = useState<File | null>(null);
  const [adultPhoto, setAdultPhoto] = useState<File | null>(null);
  const [originalImage, setOriginalImage] = useState<string | null>(null);
  const [displayedImage, setDisplayedImage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isFiltering, setIsFiltering] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [aspectRatio, setAspectRatio] = useState<string>('1:1');
  const [selectedFilter, setSelectedFilter] = useState<string>('Original');
  const [filterIntensity, setFilterIntensity] = useState<number>(100);
  
  const debounceTimeout = useRef<number | null>(null);

  const handleGenerateClick = useCallback(async () => {
    if (!childPhoto || !adultPhoto) {
      setError("Please upload both photos before generating.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setOriginalImage(null);
    setDisplayedImage(null);
    setSelectedFilter('Original');
    setFilterIntensity(100);

    try {
      const childPhotoData = await fileToBase64(childPhoto);
      const adultPhotoData = await fileToBase64(adultPhoto);

      const resultBase64 = await generateHuggingImage(childPhotoData, adultPhotoData, aspectRatio);
      setOriginalImage(resultBase64);
      setDisplayedImage(resultBase64);
    } catch (err) {
      console.error(err);
      setError("Oops! The AI couldn't create an image from the photos provided. This can sometimes happen with certain pictures. Please try again with a different pair of clear photos.");
    } finally {
      setIsLoading(false);
    }
  }, [childPhoto, adultPhoto, aspectRatio]);
  
  const handleFilterChange = useCallback(async (filter: string) => {
    if (!originalImage || isFiltering) return;

    setSelectedFilter(filter);
    setFilterIntensity(100); // Reset intensity when changing filter

    if (filter === 'Original') {
      setDisplayedImage(originalImage);
      return;
    }

    setIsFiltering(true);
    setError(null);

    try {
      const filteredResultBase64 = await applyImageFilter(originalImage, filter, 100);
      setDisplayedImage(filteredResultBase64);
    } catch (err) {
        if (err instanceof Error) {
            setError(err.message);
        } else {
            setError("An unknown error occurred while applying the filter.");
        }
    } finally {
        setIsFiltering(false);
    }

  }, [originalImage, isFiltering]);

  const handleIntensityChange = useCallback((intensity: number) => {
    setFilterIntensity(intensity);

    if (!originalImage || selectedFilter === 'Original') return;

    if (debounceTimeout.current) {
        clearTimeout(debounceTimeout.current);
    }

    debounceTimeout.current = window.setTimeout(async () => {
        setIsFiltering(true);
        setError(null);
        try {
            const filteredResultBase64 = await applyImageFilter(originalImage, selectedFilter, intensity);
            setDisplayedImage(filteredResultBase64);
        } catch (err) {
            if (err instanceof Error) {
                setError(err.message);
            } else {
                setError("An unknown error occurred while applying the filter.");
            }
        } finally {
            setIsFiltering(false);
        }
    }, 300); // 300ms debounce delay
}, [originalImage, selectedFilter]);

  const aspectRatios = [
    { value: '1:1', label: 'Square' },
    { value: '16:9', label: 'Landscape' },
    { value: '9:16', label: 'Portrait' },
  ]

  return (
    <div className="bg-gray-900 text-white min-h-screen flex flex-col font-sans relative overflow-hidden">
      <div className="background-container">
        <div className="orb orb1"></div>
        <div className="orb orb2"></div>
        <div className="orb orb3"></div>
      </div>
      <div className="relative z-10 flex flex-col min-h-screen">
        <Header />
        <main className="flex-grow container mx-auto px-4 py-8 flex flex-col items-center">
          <p className="text-center text-lg text-gray-300 max-w-2xl mb-10">
            Upload a childhood photo and a recent one. Our AI will create a unique image of you hugging your younger self.
          </p>

          <div className="w-full max-w-4xl grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
            <ImageUploader
              id="child-photo"
              label="Your Childhood Photo"
              onFileSelect={setChildPhoto}
            />
            <ImageUploader
              id="adult-photo"
              label="Your Recent Photo"
              onFileSelect={setAdultPhoto}
            />
          </div>

          <div className="flex flex-col items-center gap-6 mb-8 w-full max-w-md">
            <div className="w-full">
              <label className="block text-center text-gray-300 font-medium mb-3">
                Choose Aspect Ratio
              </label>
              <div className="flex justify-center items-center gap-2 sm:gap-4 bg-gray-800 p-2 rounded-full">
                {aspectRatios.map(({value, label}) => (
                    <button
                        key={value}
                        onClick={() => setAspectRatio(value)}
                        className={`w-full px-4 py-2 rounded-full text-sm font-semibold transition-all duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-indigo-500 ${aspectRatio === value ? 'bg-indigo-600 text-white shadow-md' : 'bg-transparent hover:bg-gray-700 text-gray-300'}`}
                    >
                        {value} <span className="hidden sm:inline">({label})</span>
                    </button>
                ))}
              </div>
            </div>

            <button
              onClick={handleGenerateClick}
              disabled={!childPhoto || !adultPhoto || isLoading}
              className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-900 disabled:text-gray-400 disabled:cursor-not-allowed text-white font-bold py-3 px-10 rounded-full transition-all duration-300 ease-in-out text-xl shadow-lg shadow-indigo-600/30 focus:outline-none focus:ring-4 focus:ring-indigo-500/50"
            >
              {isLoading ? 'Generating...' : 'Create My Image'}
            </button>
          </div>
          
          {error && <p className="text-red-400 bg-red-900/30 border border-red-500 rounded-lg p-3 text-center w-full max-w-4xl">{error}</p>}
          
          <GeneratedImageDisplay 
            isLoading={isLoading}
            isFiltering={isFiltering}
            generatedImage={displayedImage}
            selectedFilter={selectedFilter}
            onFilterChange={handleFilterChange}
            filterIntensity={filterIntensity}
            onIntensityChange={handleIntensityChange}
          />
        </main>
        <Footer />
      </div>
    </div>
  );
};

export default App;