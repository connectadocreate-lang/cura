import React, { useState } from 'react';

interface GeneratedImageDisplayProps {
  isLoading: boolean;
  isFiltering: boolean;
  generatedImage: string | null;
  selectedFilter: string;
  onFilterChange: (filter: string) => void;
  filterIntensity: number;
  onIntensityChange: (intensity: number) => void;
}

// --- ICONS ---
const DownloadIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
    </svg>
);
const ShareIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12s-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.368a3 3 0 105.367 2.684 3 3 0 00-5.367-2.684z" />
    </svg>
);

// --- LOADING & PLACEHOLDER COMPONENTS ---
const loadingSteps = [
  "Analyzing childhood photo...",
  "Analyzing recent photo...",
  "Identifying key features...",
  "Compositing the images...",
  "Applying natural lighting...",
  "Finalizing your memory...",
];

const LoadingIndicator: React.FC = () => {
    const [currentStep, setCurrentStep] = useState(0);

    React.useEffect(() => {
        const interval = setInterval(() => {
            setCurrentStep((prevStep) => (prevStep + 1) % loadingSteps.length);
        }, 2500);

        return () => clearInterval(interval);
    }, []);

    return (
        <div className="flex flex-col items-center justify-center text-center">
            <div className="relative h-24 w-24">
                <div className="absolute inset-0 border-4 border-indigo-500 rounded-full animate-spin" style={{ animationDuration: '2s' }}></div>
                <div className="absolute inset-2 border-4 border-purple-400 border-t-transparent rounded-full animate-spin" style={{ animationDuration: '1.5s', animationDirection: 'reverse' }}></div>
            </div>
            <p className="mt-6 text-lg text-gray-300 transition-opacity duration-500">{loadingSteps[currentStep]}</p>
            <p className="mt-2 text-sm text-gray-500">(This can take up to a minute)</p>
        </div>
    );
};

const Placeholder: React.FC = () => (
    <div className="text-center text-gray-500">
        <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-24 w-24" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
        </svg>
        <p className="mt-4 text-lg">Your generated image will appear here.</p>
    </div>
);

const FilteringIndicator: React.FC = () => (
    <div className="absolute inset-0 bg-gray-900/70 flex flex-col items-center justify-center rounded-lg backdrop-blur-sm z-10">
        <div className="relative h-16 w-16">
            <div className="absolute inset-0 border-2 border-green-500 rounded-full animate-spin"></div>
        </div>
        <p className="mt-4 text-white">Applying filter...</p>
    </div>
);

// --- FILTER CONTROLS ---
const FilterSelector: React.FC<{
  selectedFilter: string;
  onFilterChange: (filter: string) => void;
  disabled: boolean;
}> = ({ selectedFilter, onFilterChange, disabled }) => {
  const filters = ['Original', 'Vintage', 'Black and White', 'Sepia'];

  return (
    <div className="w-full flex flex-col items-center">
      <h3 className="text-lg font-semibold text-gray-300 mb-3">Photo Filters</h3>
      <div className="flex flex-wrap justify-center gap-2 bg-gray-800 p-2 rounded-full">
        {filters.map((filter) => (
          <button
            key={filter}
            onClick={() => onFilterChange(filter)}
            disabled={disabled}
            className={`px-4 py-2 rounded-full text-sm font-semibold transition-all duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-indigo-500 disabled:cursor-not-allowed disabled:opacity-50 ${
              selectedFilter === filter
                ? 'bg-indigo-600 text-white shadow-md'
                : 'bg-transparent hover:bg-gray-700 text-gray-300'
            }`}
          >
            {filter}
          </button>
        ))}
      </div>
    </div>
  );
};

const FilterIntensitySlider: React.FC<{
    intensity: number;
    onIntensityChange: (intensity: number) => void;
    disabled: boolean;
}> = ({ intensity, onIntensityChange, disabled }) => (
    <div className="w-full max-w-xs flex flex-col items-center mt-4">
        <label htmlFor="intensity-slider" className="text-sm font-medium text-gray-400 mb-2">
            Filter Intensity: {intensity}%
        </label>
        <input
            id="intensity-slider"
            type="range"
            min="0"
            max="100"
            value={intensity}
            disabled={disabled}
            onChange={(e) => onIntensityChange(parseInt(e.target.value, 10))}
            className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-indigo-500 disabled:cursor-not-allowed"
            aria-label="Filter intensity"
        />
    </div>
);

// --- SHARE MODAL ---
const ShareModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  message: string;
  setMessage: (message: string) => void;
}> = ({ isOpen, onClose, message, setMessage }) => {
  if (!isOpen) return null;

  const appUrl = window.location.href;
  const encodedAppUrl = encodeURIComponent(appUrl);
  const encodedMessage = encodeURIComponent(message);

  const socialLinks = {
    twitter: `https://twitter.com/intent/tweet?text=${encodedMessage}&url=${encodedAppUrl}`,
    facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodedAppUrl}&quote=${encodedMessage}`,
    reddit: `https://www.reddit.com/submit?url=${encodedAppUrl}&title=${encodedMessage}`,
  };

  const TwitterIcon = () => (
    <svg className="h-8 w-8" role="img" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
  );
  const FacebookIcon = () => (
    <svg className="h-8 w-8" role="img" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M22 12c0-5.52-4.48-10-10-10S2 6.48 2 12c0 4.84 3.44 8.87 8 9.8V15H8v-3h2V9.5C10 7.57 11.57 6 13.5 6H16v3h-2c-.55 0-1 .45-1 1v2h3v3h-3v6.95c5.05-.5 9-4.76 9-9.95z"/></svg>
  );
  const RedditIcon = () => (
    <svg className="h-8 w-8" role="img" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M12 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0zm5.01 4.744c.688 0 1.25.561 1.25 1.249a1.25 1.25 0 0 1-2.498.056l-2.597-.547-.8 3.747c1.824.07 3.48.632 4.674 1.488.308-.309.73-.491 1.207-.491.968 0 1.754.786 1.754 1.754 0 .716-.435 1.333-1.01 1.614a3.111 3.111 0 0 1 .042.52c0 2.694-3.13 4.87-7.004 4.87-3.874 0-7.004-2.176-7.004-4.87 0-.183.015-.366.043-.534A1.748 1.748 0 0 1 4.028 12c0-.968.786-1.754 1.754-1.754.463 0 .898.196 1.207.49 1.207-.883 2.878-1.43 4.744-1.487l.885-4.182a.342.342 0 0 1 .14-.197.34.34 0 0 1 .238-.042l2.906.617a1.214 1.214 0 0 1 1.108-.701zM9.25 12.469c-1.03 0-1.868.838-1.868 1.868 0 1.03.838 1.868 1.868 1.868 1.03 0 1.868-.838 1.868-1.868 0-1.03-.838-1.868-1.868-1.868zm5.5 0c-1.03 0-1.868.838-1.868 1.868 0 1.03.838 1.868 1.868 1.868 1.03 0 1.868-.838 1.868-1.868 0-1.03-.838-1.868-1.868-1.868zM12 10.812a.6.6 0 0 1-.6-.6v-1.8a.6.6 0 0 1 1.2 0v1.8a.6.6 0 0 1-.6.6z"/></svg>
  );

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 transition-opacity animate-fade-in" onClick={onClose} aria-modal="true" role="dialog">
      <div className="bg-gray-800 rounded-lg shadow-xl p-6 w-full max-w-md mx-4 text-white relative border border-gray-700" onClick={e => e.stopPropagation()}>
        <button onClick={onClose} className="absolute top-3 right-3 text-gray-500 hover:text-white transition-colors" aria-label="Close modal">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
        </button>

        <h3 className="text-2xl font-bold mb-4 text-center">Share your Creation</h3>
        <textarea
          value={message}
          onChange={e => setMessage(e.target.value)}
          className="w-full bg-gray-900 border border-gray-600 rounded-md p-3 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition duration-200"
          rows={4}
          aria-label="Share message"
        />
        <p className="text-xs text-gray-400 mt-1">Note: This will share a link to the app, not the image itself.</p>
        
        <div className="flex justify-center items-center gap-6 mt-6">
          <a href={socialLinks.twitter} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors" aria-label="Share on Twitter"><TwitterIcon /></a>
          <a href={socialLinks.facebook} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-blue-500 transition-colors" aria-label="Share on Facebook"><FacebookIcon /></a>
          <a href={socialLinks.reddit} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-orange-500 transition-colors" aria-label="Share on Reddit"><RedditIcon /></a>
        </div>
      </div>
    </div>
  );
}

// --- MAIN COMPONENT ---
export const GeneratedImageDisplay: React.FC<GeneratedImageDisplayProps> = ({ 
  isLoading, 
  isFiltering,
  generatedImage, 
  selectedFilter,
  onFilterChange,
  filterIntensity,
  onIntensityChange
}) => {
  const [showDownloadMessage, setShowDownloadMessage] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [shareMessage, setShareMessage] = useState("Check out this touching image I created with Cura! It shows me hugging my younger self. You can make one too! #CuraAI #AIArt #PastAndPresent");

  const handleDownloadClick = () => {
    setShowDownloadMessage(true);
    setTimeout(() => {
      setShowDownloadMessage(false);
    }, 3000);
  };
  
  const imageSrc = generatedImage ? `data:image/png;base64,${generatedImage}` : null;

  return (
    <div className="w-full max-w-4xl mt-8">
      <h2 className="text-center text-3xl font-bold mb-6 text-gray-100">Result</h2>
      <div className="w-full aspect-square bg-gray-800 border-2 border-gray-700 rounded-lg flex items-center justify-center p-4 transition-all duration-300 relative">
        {isLoading ? (
          <LoadingIndicator />
        ) : imageSrc ? (
          <img src={imageSrc} alt="Generated" className="max-w-full max-h-full object-contain rounded-md" />
        ) : (
          <Placeholder />
        )}
        {isFiltering && <FilteringIndicator />}
      </div>

      {imageSrc && !isLoading && (
        <>
          <div className="mt-6 flex flex-col items-center">
            <FilterSelector 
              selectedFilter={selectedFilter}
              onFilterChange={onFilterChange}
              disabled={isFiltering}
            />
            {selectedFilter !== 'Original' && (
              <FilterIntensitySlider 
                intensity={filterIntensity}
                onIntensityChange={onIntensityChange}
                disabled={isFiltering}
              />
            )}
          </div>
          <div className="text-center mt-6 flex flex-col items-center justify-start min-h-[4rem]">
            <div className="flex flex-col sm:flex-row gap-4">
              <a
                href={imageSrc}
                download={`cura-generated-${selectedFilter.toLowerCase().replace(/\s+/g, '-')}.png`}
                onClick={handleDownloadClick}
                className="inline-flex items-center justify-center bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-6 rounded-full transition-colors duration-300"
              >
                <DownloadIcon />
                Download Image
              </a>
              <button
                onClick={() => setIsShareModalOpen(true)}
                className="inline-flex items-center justify-center bg-gray-600 hover:bg-gray-500 text-white font-bold py-2 px-6 rounded-full transition-colors duration-300"
              >
                <ShareIcon />
                Share
              </button>
            </div>

            {showDownloadMessage && (
              <p className="text-green-400 text-sm mt-2 animate-fade-in">
                Image downloading...
              </p>
            )}
          </div>
          <ShareModal 
            isOpen={isShareModalOpen}
            onClose={() => setIsShareModalOpen(false)}
            message={shareMessage}
            setMessage={setShareMessage}
          />
        </>
      )}
    </div>
  );
};