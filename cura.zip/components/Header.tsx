
import React from 'react';

export const Header: React.FC = () => {
  return (
    <header className="py-6 w-full text-center">
      <h1 className="text-5xl md:text-6xl font-extrabold">
        <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-indigo-600">
          Cura
        </span>
      </h1>
      <p className="mt-2 text-gray-400 text-lg">Your Past and Present, United.</p>
    </header>
  );
};
