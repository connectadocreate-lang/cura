import { GoogleGenAI, Modality } from "@google/genai";

interface ImageData {
  data: string;
  mimeType: string;
}

export const generateHuggingImage = async (
  childPhotoData: ImageData,
  adultPhotoData: ImageData,
  aspectRatio: string,
): Promise<string> => {
  if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable is not set.");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const PROMPT = `
Analyze the two provided images. The first image contains a person as a child. The second image contains the same person as an adult. 
Create a new, photorealistic image where the adult version of the person is gently and affectionately hugging their younger, child self. 
Both individuals should be clearly recognizable from the source photos. The interaction should appear natural, warm, and emotionally resonant. 
Place them against a completely clean, smooth, soft white background. Ensure the lighting is natural and soft, creating a gentle and cohesive scene. 
The final image should be a touching composite that looks like a single, unified photograph.
IMPORTANT: The final image MUST have a ${aspectRatio} aspect ratio.
`;

  const childPhotoPart = {
    inlineData: {
      data: childPhotoData.data,
      mimeType: childPhotoData.mimeType,
    },
  };

  const adultPhotoPart = {
    inlineData: {
      data: adultPhotoData.data,
      mimeType: adultPhotoData.mimeType,
    },
  };

  const textPart = {
    text: PROMPT,
  };

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [childPhotoPart, adultPhotoPart, textPart],
      },
      config: {
        responseModalities: [Modality.IMAGE],
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts ?? []) {
      if (part.inlineData) {
        return part.inlineData.data;
      }
    }
    
    throw new Error("No image data found in the API response.");
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("The AI model failed to generate an image. This can happen with certain images. Please try again with a different pair of photos.");
  }
};

export const applyImageFilter = async (
  base64ImageData: string,
  filterName: string,
  intensity: number
): Promise<string> => {
  if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable is not set.");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const PROMPT = `
Apply a '${filterName}' style filter to the provided image with an intensity of ${intensity}%.
A 100% intensity means the full effect is applied. A 0% intensity should result in an image identical to the original. A 50% intensity should be a half-strength application of the filter.
The composition, subjects, and all elements of the image must remain exactly the same.
Only the color grading, tone, and overall aesthetic should be modified to match the '${filterName}' style at the specified intensity.
For 'Black and White', convert the image to monochrome.
For 'Sepia', apply a brownish monochrome tint.
For 'Vintage', give it a faded, aged look, possibly with slight film grain.
Do not add, remove, or change any content in the image.
`;

  const imagePart = {
    inlineData: {
      data: base64ImageData,
      mimeType: 'image/png', 
    },
  };

  const textPart = {
    text: PROMPT,
  };

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [imagePart, textPart],
      },
      config: {
        responseModalities: [Modality.IMAGE],
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts ?? []) {
      if (part.inlineData) {
        return part.inlineData.data;
      }
    }
    
    throw new Error("No image data found in the filter API response.");
  } catch (error) {
    console.error("Error calling Gemini API for filtering:", error);
    throw new Error(`The AI model failed to apply the ${filterName} filter.`);
  }
};